//Laura Ivon Montelongo Mart�nez_177291_19 Abril de 2022
//ACTIVIDAD CON ARREGLO DINAMICO
#include<stdio.h>
#include <stdlib.h>
#include<math.h>
#include<time.h>
#include <windows.h>

int main()
{
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	int numElem,i,suma=0,suma2=0;
	int *vector;
	SetConsoleTextAttribute(hConsole,15);
	printf("Cuantos elementos quieres: ");
	scanf("%d",&numElem);
	
	vector=(int*)malloc(numElem*sizeof(int));
	if(vector==NULL)
	{
		printf("Problemas reservando memoria");
		exit(1);
	}

	//trabajamos con el vector ya que tiene la cantidad necesaria de reserva de memoria
	
	//llenado del arreglo
	srand(time(NULL));
	for(i=0;i<numElem;i++)
	{
		vector[i]=20+rand()%(51-20);
		
	}
	
	//mostramos el contenido del arreglo
	SetConsoleTextAttribute(hConsole,6);
	printf("\nCONTENIDO DEL ARREGLO\n");
	SetConsoleTextAttribute(hConsole,15);
	for (i=0;i<numElem;i++)
	{
		printf("%d\t ",vector[i]);
	}
	
	//Sumatoria de todos los n�meros pares que se encuentren en el arreglo
	for (i=0;i<numElem;i++)
	{
		if(vector[i]%2==0)
		{
			suma=suma+vector[i];
		}
	}
	SetConsoleTextAttribute(hConsole,9);
	printf("\n\n*Sumatoria de los numeros pares en el arreglo: %d ",suma);
	SetConsoleTextAttribute(hConsole,15);


	//Sumatoria de todos los n�meros que se encuentren en las posiciones impares del arreglo
	for (i=0;i<numElem;i++)
	{
		if(i%2==0)
		{
			printf("");
		}
		else
		{
			suma2=suma2+vector[i];
			printf("\n\nPosicion: %d --> %d",i,vector[i]);
		}
	}
	SetConsoleTextAttribute(hConsole,4);
	printf("\n\n*Sumatoria de posiciones impares en el arreglo: %d",suma2);
	SetConsoleTextAttribute(hConsole,15);
	
	// liberamos memoria
	free (vector);
	
	return 0;
}
