#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<string.h>
//Laura Ivon Montelongo Mart�nez - 177291 - 12 de Mayo del 2022
struct agenda
{
	char nombre[25];
	char telefono[12];
	int edad;
	struct agenda*siguiente;
};

struct agenda *primero=NULL, *ultimo=NULL;

//Prototipos de funciones
void nuevo_elemento();
void mostrar_elemento();
void buscar_elemento();
void eliminar_elemento();

int main()
{
	nuevo_elemento();
	mostrar_elemento();
	buscar_elemento();
	eliminar_elemento();
}

	void nuevo_elemento()
	{
		struct agenda*nuevo;
	int n=0,opc;
	printf("INSERCION DE ELEMENTOS PARA SU LISTA");
		do
		{
			//reservamos memoria para el nuevo elemento
			nuevo=(struct agenda*) malloc (sizeof(struct agenda));
			if (nuevo==NULL)
			{
				printf("No hay memoria disponible!\n");
				exit(0);
			}
		

			printf("\nNombre: ");
			scanf("%s",nuevo->nombre);
				
			printf("Telefono: ");
			scanf("%s",nuevo->telefono);
			
			printf("Edad: ");
			scanf("%d",&nuevo->edad);
			
			nuevo->siguiente=NULL;
			if(primero==NULL)
			{
				primero=nuevo;
				ultimo=nuevo;
				n++;
			}
			else
			{
				printf("\nInsertar al inicio de la lista\n");
				nuevo->siguiente=primero;
				primero=nuevo;
				n++;
			}
			
			printf("\nDesea insertar otro elemento? 1=si 1 --> ");
			scanf("%d",&opc);
			
			
		}while(opc!=0);
	}
	
	void mostrar_elemento()
	{
		struct agenda*auxiliar;
		int i;
		i=1;
		auxiliar=primero;
		printf("\nLISTA COMPLETA: \n");
		printf("--------------------");
		
		printf("\nNombre  Edad  Telefono\n");
		while(auxiliar!=NULL)
		{
			printf("%s, \t%d , \t%s\n",auxiliar->nombre,auxiliar->edad,auxiliar->telefono);
			auxiliar=auxiliar->siguiente;
			i++;
		}
		printf("--------------------");
	}
	
	void buscar_elemento()
	{
		bool band =false;
		struct agenda*actual;
		actual = primero;
		
		int buscar,i=1,opc1;
		
			while(actual!=NULL)
			{
				printf("\nEdad a buscar: ");
				scanf("%d",&buscar);
				if(actual->edad==buscar)
				{
					band=true;
					printf("\nDato encontrado!");
					printf("\nNombre  Edad  Telefono\n");
					printf("%s, \t%d \t%s\n",actual->nombre,actual->edad,actual->telefono);
				}
				else
				{
					printf("\nDato no encontado!");
				}
				actual=actual->siguiente;
				i++;
			}	
			
			
	}
	
	void eliminar_elemento()
	 {
		bool band =false;
		struct agenda*actual;
		actual= primero;
		
		int buscar,i=1,op;
		printf("\n\nOPCION: Borrar un dato");
		printf("\nDesea eliminar algun elemento de edad? 1=si");
		scanf("%d",&op);
		if(op==1)
		{
			while(actual->edad!=NULL)
			{
				printf("\nEdad a buscar: ");
				scanf("%d",&buscar);
				if(actual->edad==buscar)
				{
					free(actual);
					printf("\nDato Borrado!");
					printf("\nNombre  Edad  Telefono\n");
					printf("%s, \t%d \t%s\n",actual->nombre,actual->edad,actual->telefono);
				}
				actual=actual->siguiente;
				i++;
			}
			mostrar_elemento();
		}
		else
		printf("Hasta Luego");
			
	 }
	

