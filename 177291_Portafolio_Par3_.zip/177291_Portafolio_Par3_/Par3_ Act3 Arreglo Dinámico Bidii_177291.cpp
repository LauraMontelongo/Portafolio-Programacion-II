//Laura Ivon Montelongo Mart�nez_177291_20 Abril de 2022
#include<stdio.h>
#include <stdlib.h>
#include<math.h>
#include<time.h>
#include <windows.h>
int main()
{
	int x,y,fil,colum,rest,resul;
	int **tabla,**tabla2;
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	
	SetConsoleTextAttribute(hConsole,15);
	//Pedimos los valores de las filas y las columnas
	printf("Cuantas filas va a querer: ");
	scanf("%d",&fil);
	
	printf("Cuantas columnas va a querer: ");
	scanf("%d",&colum);
	
	
	//reserva de memoria dinamica
	tabla = (int **)malloc (fil*sizeof(int *)); //reserva de memoria para las filas
	 if (tabla==NULL)
	{
		printf("No hay memoria suficiente ");
		exit (1);
	}
	
	for (x=0;x<fil;x++) //cada fila tiene un numero de columnas
	{
		tabla[x] = (int *) malloc (colum*sizeof(int));
		// Revisamos los malloc para cada columna
		if (tabla[x] == NULL)
		 {
		 	printf("No hay memoria suficiente\n");
			return -1;
		 }
	}
	
	
	tabla2= (int **)malloc (fil*sizeof(int *)); //reserva de memoria para las filas
	 if (tabla2==NULL)
	{
		printf("No hay memoria suficiente ");
		exit (1);
	}
	
	for (x=0;x<fil;x++) //cada fila tiene un numero de columnas
	{
		tabla2[x] = (int *) malloc (colum*sizeof(int));
		// Revisamos los malloc para cada columna
		if (tabla2[x] == NULL)
		 {
		 	printf("No hay memoria suficiente\n");
			return -1;
		 }
	}
	
	SetConsoleTextAttribute(hConsole,13);
	printf("\nRESERVA DE MEMORIA EXITOSA");
	SetConsoleTextAttribute(hConsole,15);
	
	
	// llenamos las dos matrizes 
	srand(time(NULL));
	for (x=0;x<fil;x++)
	{
		for (y=0;y<colum;y++)
		{
			tabla[x][y]=20+rand()%(81-20);
			tabla2[x][y]=tabla[x][y];
		}
		printf("\n");//Salto para la siguiente fila
	}
	
	// Mostramos las matrizes
	SetConsoleTextAttribute(hConsole,14);
	printf("\nCONTENIDO DE LA PRIMERA MATRIZ\n");
	SetConsoleTextAttribute(hConsole,15);
	for (x=0;x<fil;x++)
	{
		for (y=0;y<colum;y++)
		{
			printf("%d\t",tabla[x][y]);
		}
		printf("\n"); 
	}
	
	printf("\n*Cantidad a restar para las celdas pares con valores >= a 40: ");
	scanf("%d",&resul);
	
	SetConsoleTextAttribute(hConsole,2);
	printf("\nCONTENIDO DE LA SEGUNDA MATRIZ\n"); 
	SetConsoleTextAttribute(hConsole,15);
	for (x=0;x<fil;x++)
	{
		for (y=0;y<colum;y++)
		{
			if((x%2==0) && (y%2==0) && (tabla2[x][y]>=40))
			{
				tabla2[x][y]=tabla2[x][y]-resul;
			}
			printf("%d\t ",tabla2[x][y]);
		}
		printf("\n"); 
	}
	


	for (x=0;x<fil;x++) //liberamos la memoria para todas las filas de la matriz 1
	{
		free(tabla[x]);
	}
	free (tabla);
	
	
	for (x=0;x<fil;x++) //liberamos la memoria para todas las filas de la matriz 2
	{
		free(tabla2[x]);
	}
	free (tabla2);
	
	
	return 0;
}
