//Laura Ivon Montelongo Mart�nez_177291 - 26 de Abril de 2022
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include <windows.h>
//DECLARACION DE LA ESTRUCTURA cd:
struct cd
{
	char titulo[30];
	char artista[25];
	int nro_canciones;
	float precio;
	char fecha_compra[10];
};

//PROTOTIPOS DE FUNCIONES
void lee();
void mostrar();
void menu();

//Array de 3 elementos de tipo estructura cd llamado mis_cds:
cd mis_cds[3];
int main()
{
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	int opc,cont=0;
	SetConsoleTextAttribute(hConsole,5);
	printf("\t\t---MENU DE OPCIONES---\n");
	SetConsoleTextAttribute(hConsole,15);
	printf("\n1.-Leer informacion");
	printf("\n2.-Mostrar la informacion contenida");
	printf("\n3.-Menu");
	printf("\n4.-Salir");
	do
	{
		
		do//Ciclo que identifca que si su primera opcion es 2, aun no ha introducido ningun dato
		{
			printf("\n\nQue opcion quiere elegir: ");
			scanf("%d",&opc);
			if(opc!=2)
			{
				cont++;
			}
			else
			{
				SetConsoleTextAttribute(hConsole,4);
				printf("\nAun no a insertado ningun dato!");
				SetConsoleTextAttribute(hConsole,15);
			}
		}while((cont==0) &&(opc==2));
		
		switch(opc)
		{
			case 1: 
				lee();
				break;
				
			case 2:
				mostrar();

				break;
				
			case 3: 
				menu();
				break;
			
			case 4:
				SetConsoleTextAttribute(hConsole,14);
				printf("\nHasta Luego");
				SetConsoleTextAttribute(hConsole,15);
				break;
				
			default:
				SetConsoleTextAttribute(hConsole,4);
				printf("\nEsta opcion no es valida");
				SetConsoleTextAttribute(hConsole,15);
				break;
				

		}
	}while(opc!=4);
}

	void lee()
	{
		HANDLE hConsole;
		hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
		for(int i=0;i<3;i++)
		{
			SetConsoleTextAttribute(hConsole,10);
			printf("\n*Cual es el titulo de su cd: ");
			SetConsoleTextAttribute(hConsole,15);
			scanf("%s",mis_cds[i].titulo);
		}
				
		for(int i=0;i<3;i++)
		{
			SetConsoleTextAttribute(hConsole,9);
			printf("\n*Quien es el artista: ");
			SetConsoleTextAttribute(hConsole,15);
			scanf("%s",mis_cds[i].artista);
		}
				
		for(int i=0;i<3;i++)
		{
			SetConsoleTextAttribute(hConsole,6);
			printf("\n*Cual es el numero de canciones: ");
			SetConsoleTextAttribute(hConsole,15);
			scanf("%d",&mis_cds[i].nro_canciones);
		}
				
		for(int i=0;i<3;i++)
		{
			SetConsoleTextAttribute(hConsole,14);
			printf("\n*Cual es su precio: ");
			SetConsoleTextAttribute(hConsole,15);
			scanf("%f",&mis_cds[i].precio);
		}
				
		for(int i=0;i<3;i++)
		{
			SetConsoleTextAttribute(hConsole,13);
			printf("\n*Cuando fue la fecha de su compra: ");
			SetConsoleTextAttribute(hConsole,15);
			scanf("%s",mis_cds[i].fecha_compra);
		}
	}
	
	void mostrar()
	{
     	printf("\n\n-->Titulo de su cd\n");
		for(int i=0;i<3;i++) 
		{
			printf("\n%s",mis_cds[i].titulo);
		}
		
		printf("\n\n-->Artista\n");
		for(int i=0;i<3;i++) 
		{
			printf("\n%s",mis_cds[i].artista);
		}
		
		printf("\n\n-->Numero de canciones\n");
		for(int i=0;i<3;i++) 
		{
			printf("\n%0.1d",mis_cds[i].nro_canciones);
		}
		
		printf("\n\n-->Precio\n");
		for(int i=0;i<3;i++) 
		{
			printf("\n%0.2f",mis_cds[i].precio);
		}
		
		printf("\n\n-->Fecha de su compra\n");
		for(int i=0;i<3;i++) 
		{
			printf("\n%s",mis_cds[i].fecha_compra);
		}
	
	}
	
	void menu()
	{
		HANDLE hConsole;
		hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
		SetConsoleTextAttribute(hConsole,13);
		printf("\n\t\t---MENU DE OPCIONES---");
		SetConsoleTextAttribute(hConsole,15);
		printf("\n1.-Leer informacion");
		printf("\n2.-Mostrar la informacion contenida");
		printf("\n3.-Menu");
		printf("\n4.-Salir");
	}
