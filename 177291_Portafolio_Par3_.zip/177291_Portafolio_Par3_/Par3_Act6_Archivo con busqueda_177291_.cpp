#include <stdio.h>
#include <string.h>
//Laura Ivon Montelongo Mart�nez_177291 - 9 de Mayo de 2022
void menu();
void CrearFichero(FILE *Fichero1);
void InsertarDatos(FILE *Fichero1);
void VerDatos(FILE *Fichero1);
void BuscarDato(FILE *Fichero1);
 
struct sRegistro {
   char Nombre[25];
   int Edad;
   float Sueldo;
} registro;
 
main()
{
 	int opcion;
 	int exit = 0;
 	FILE *Fichero1;
 	while (opcion!=5)
 	{	
 		menu();
 		printf("\n\nOpcion: ");
 		scanf("%d", &opcion);
 
 		switch(opcion)
 		{
 			case 1:
 				CrearFichero(Fichero1);
 			break;
 			case 2:
 				InsertarDatos(Fichero1);
 			break;
 			case 3:
 				VerDatos(Fichero1);
 			break;
 			case 4:
 				BuscarDato(Fichero1);
 			case 5:
 				printf("");
 			break;
 			default:
				printf("\nopcion no valida");
			break;
 		}
 	}
 
 	return 0;
}
 
void menu()
{
 	printf("\nMenu:");
 	printf("\n\t1. Crear fichero");
 	printf("\n\t2. Insertar datos");
 	printf("\n\t3. Ver datos");
 	printf("\n\t4. Buscar datos");
 	printf("\n\t5. Salir");
}
 
void CrearFichero(FILE *Fichero1)
{


 	Fichero1 = fopen("archivo.txt", "r");
 
 	if(!Fichero1)
 	{
 		Fichero1 = fopen("archivo.txt", "w");
 		printf("\nArchivo creado!");
 	}
 	else
 	{
 		printf("\nEl fichero ya existe!");
 	}
 
 	fclose (Fichero1);
 
 	return;

}
 
void InsertarDatos(FILE *Fichero1)
{
 	Fichero1 = fopen("archivo.txt", "a+");
 
	printf("\nDigita el nombre: ");
	scanf("%s", registro.Nombre);
 
	printf("\nDigita la edad: ");
	scanf("%d", &registro.Edad);
 
	printf("\nDigita el sueldo: ");
	scanf("%f", &registro.Sueldo);
 
	fwrite(&registro, sizeof(struct sRegistro),1, Fichero1);
 
	fclose(Fichero1);
 
	return;
}
 


	void VerDatos(FILE *Fichero1)
	{
		int numero = 1;
	 
		Fichero1 = fopen("archivo.txt", "r");
	 
		if(Fichero1 == NULL)
		{
			printf("\nFichero no existe! \nPor favor creelo");
			return;
		}
	 
		fread(&registro, sizeof(struct sRegistro), 1, Fichero1);
	 
		printf("\nNombre \tEdad \tSueldo");
	 
		while(!feof(Fichero1))
		{
			printf("\n%s \t%d \t%0.2f\n" , registro.Nombre,registro.Edad,registro.Sueldo);
			fread(&registro, sizeof(struct sRegistro), 1, Fichero1);
			numero++;
		}
	
	 
		fclose(Fichero1);
		return;

	}


	void BuscarDato(FILE *Fichero1)
	{
	    
		char nombre[25];
		int bandera=0;
		printf("\nQue edad quiere buscar: ");
		scanf("%s",&nombre);
		
		int numero=1;
		
		Fichero1=fopen("archivo.txt","r");
		
		if(Fichero1==NULL)
		{
			printf("\nFichero no existe! \nPor favor creelo");
			return;
		}
		
		
		fread(&registro, sizeof(struct sRegistro), 1, Fichero1);
		while(!feof(Fichero1))
		{
			if(strstr(nombre,registro.Nombre)!=NULL)
			{
				printf("\n--Dato encontado exitosamente--\n");
				printf("\nNombre \tEdad \tSueldo");
				printf("\n%s \t%d \t%0.2f\n\n" , registro.Nombre,registro.Edad,registro.Sueldo);
				bandera=1;
			}
			fread(&registro, sizeof(struct sRegistro), 1, Fichero1);
			
		}
		
		if(bandera==0)
		{
			printf("\nDato no encontrado\n");
		}
		fclose(Fichero1);
	
	}

