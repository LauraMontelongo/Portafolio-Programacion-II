#include<stdio.h>
#include<conio.h>
#include <stdlib.h>
#include<math.h>
#include<time.h>
#include <windows.h>
//fwrite y fread
//Laura Ivon Montelogno Mart�nez_177291 ---> 5 de Mayo del 2022

struct sRegistro {
   char Nombre[25];
   int Edad;
   float Sueldo;
} registro[3];
 
main()
{
	int exit = 0,numero=1;
	FILE *Fichero;
	HANDLE hConsole;
	hConsole=GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole,15);
	Fichero = fopen("fichero3.txt", "w+");
 
	if(Fichero == NULL)
	{
		printf("\nFichero no existe! \nPor favor creelo");
		return(0);
	}
 
 	for(int i=0;i<3;i++)
	{
		printf("\nDigita el nombre %d: ",i+1);
		scanf("%s", registro[i].Nombre);
		
		printf("\nDigita la edad: ");
		scanf("%d", &registro[i].Edad);
		
		printf("\nDigita el sueldo: ");
		scanf("%f", &registro[i].Sueldo);
		fwrite(&registro[i],sizeof(struct sRegistro), 1, Fichero);
		
	}

	
	
	fclose(Fichero);
	Fichero = fopen("fichero3.txt", "r");
	if(Fichero == NULL)
	{
		printf("\nFichero no existe! \nPor favor creelo");
		return(0);
	}

	SetConsoleTextAttribute(hConsole,14);
	printf("\n\nDATOS:\n");
	SetConsoleTextAttribute(hConsole,9);
	printf("\nNombre \tEdad \tSueldo");
	SetConsoleTextAttribute(hConsole,15);
	
	for(int i=0;i<3;i++)
	{
		fread(&registro[i], sizeof(struct sRegistro), 1, Fichero);
		printf("\n");
		printf("\n%s \t%d \t%0.2f",registro[i].Nombre,registro[i].Edad,registro[i].Sueldo);
		numero++;
	}

	fclose(Fichero);
	getch();
	return(0);
}

