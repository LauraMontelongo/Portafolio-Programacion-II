//Laura Ivon Montelongo Mart�nez_177291 - 7 de Abril de 2022
#include <stdio.h>
int main()
{
	int a=5,b=3; //Variables normales
	int z=4;//Variable normal
	int *pa,*pb,*pz; //Variables punteras
	
	//Caso 1
	pa=&a;//A pa se le asigna la direcci�n de memoria de a
	pb=&b;//A pb se le asigna la direcci�n de memoria de b
	*pa=30/(*pb+12)*(*pb);
	*pb=(*pa+13);
	printf("Valores del caso 1:\n");
	printf("\n a=%d   b=%d",a,b);//Resultado de a y b despues de usar punteros
	
	//Caso 2
	pz=&z;//A p< se le asigna la direcci�n de memoria de z
	if(*pz%7==0)
	{
		*pz=(*pz+4)/9;
	}
	else
	{
		*pz=(*pz+10);
	}
	printf("\n\nEl valor de z para el caso 2 es:\n");
	printf("\n z=%d",z);//Resultado de z despues de usar punteros
	     
}
